const lang = document.querySelector(".lang");
const langButton = document.querySelector(".lang__button");

langButton.addEventListener("click", (e) => {
  e.stopPropagation();
  langButton.classList.toggle("active")
});

document.body.addEventListener("click", (e) => {
  if (!lang.contains(e.target) && langButton.classList.contains("active")) {
    langButton.classList.remove("active");
  }
})


const menu = document.querySelector(".header__menu");
const menuButton = document.querySelector(".header__menu-button");
const menuClose = document.querySelector(".header__close");

menuButton.addEventListener("click", () => {
  document.body.classList.add("body-overflow");
  menu.classList.add("active")
});
menuClose.addEventListener("click", () => {
  document.body.classList.remove("body-overflow");
  menu.classList.remove("active")
});
